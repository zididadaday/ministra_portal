<?php

namespace Ministra\Admin\Controller;

use Ministra\Admin\Adapter\DataTableAdapter;
use Ministra\Admin\Repository\LicenseKeysRepository;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d;
use Ministra\Lib\SMACCode;
use Ministra\Lib\SMACCodeException;
use Ministra\Lib\SMACLicenseInvalidFormatException;
use Psr\Container\ContainerInterface;
use Silex\Application;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response as Response;
use Upload\File;
use Upload\Storage\FileSystem;
class LicenseKeysController extends \Ministra\Admin\Controller\BaseMinistraController
{
    protected $db;
    public function __construct(\Silex\Application $app)
    {
        parent::__construct($app, __CLASS__);
    }
    public function index()
    {
        if (empty($this->app['action_alias'])) {
            return $this->app->redirect($this->app['controller_alias'] . '/about-license-keys');
        }
        return $this->app['twig']->render($this->getTemplateName(__METHOD__));
    }
    public function about_license_keys()
    {
        return $this->app['twig']->render($this->getTemplateName(__METHOD__));
    }
    public function license_keys_list(\Ministra\Admin\Repository\LicenseKeysRepository $repository, \Psr\Container\ContainerInterface $container)
    {
        $attribute = $this->getDropdownAttribute();
        $this->checkDropdownAttribute($attribute);
        $this->app['dropdownAttribute'] = $attribute;
        $this->getCodeFilters();
        $container->set('allUserStatuses', [['id' => '1', 'title' => $this->setLocalization('Turned On')], ['id' => '2', 'title' => $this->setLocalization('Turned Off')]]);
        $container->set('allStatuses', [['id' => \Ministra\Lib\SMACCode::STATUS_NOT_ACTIVATED, 'title' => $this->setLocalization(\Ministra\Lib\SMACCode::STATUS_NOT_ACTIVATED)], ['id' => \Ministra\Lib\SMACCode::STATUS_ACTIVATED, 'title' => $this->setLocalization(\Ministra\Lib\SMACCode::STATUS_ACTIVATED)], ['id' => \Ministra\Lib\SMACCode::STATUS_MANUALLY_ENTERED, 'title' => $this->setLocalization(\Ministra\Lib\SMACCode::STATUS_MANUALLY_ENTERED)], ['id' => \Ministra\Lib\SMACCode::STATUS_BLOCKED, 'title' => $this->setLocalization('BlockedLicense')], ['id' => \Ministra\Lib\SMACCode::STATUS_RESERVED, 'title' => $this->setLocalization(\Ministra\Lib\SMACCode::STATUS_RESERVED)]]);
        $container->set('allKeyTypes', [['id' => '1,2', 'title' => $this->setLocalization('Standard')], ['id' => '3,4', 'title' => $this->setLocalization('Advanced')]]);
        $devices = $repository->findForFilters('device');
        $container->set('allDevices', \array_filter(\array_map(function ($row) {
            return !empty($row['device']) ? ['id' => $row['device'], 'title' => $row['device']] : false;
        }, !empty($devices) ? $devices : [])));
        return $this->app['twig']->render($this->getTemplateName(__METHOD__));
    }
    private function getDropdownAttribute()
    {
        $attribute = [['name' => 'key_id', 'title' => $this->setLocalization('ID'), 'checked' => false], ['name' => 'code', 'title' => $this->setLocalization('License key'), 'checked' => true], ['name' => 'key_type', 'title' => $this->setLocalization('Key type'), 'checked' => true], ['name' => 'count_clear_attempts', 'title' => $this->setLocalization('Remaining clearings'), 'searchable' => false, 'checked' => true], ['name' => 'expire_date', 'title' => $this->setLocalization('Key expiration date'), 'searchable' => false, 'checked' => true], ['name' => 'key_status', 'title' => $this->setLocalization('Status'), 'checked' => true], ['name' => 'user_id', 'title' => $this->setLocalization('User'), 'checked' => true], ['name' => 'device', 'title' => $this->setLocalization('Device type'), 'checked' => true], ['name' => 'last_active', 'title' => $this->setLocalization('User activity'), 'checked' => true], ['name' => 'action', 'title' => $this->setLocalization('Actions'), 'checked' => true, 'searchable' => false], ['name' => 'operations', 'title' => $this->setLocalization('Operations'), 'checked' => true, 'searchable' => true]];
        return $attribute;
    }
    private function getCodeFilters()
    {
        $filters = [];
        if (\array_key_exists('filters', $this->data)) {
            if (\array_key_exists('key_type', $this->data['filters']) && (string) $this->data['filters']['key_type'] !== '0') {
                $filters['SUBSTRING(`code`, 2, 1) IN' . ((string) $this->data['filters']['key_type'] == '1' ? '(1, 2)' : '(3, 4)') . ' AND 1 '] = '1';
            }
            if (\array_key_exists('request', $this->data['filters']) && (string) $this->data['filters']['request'] !== '0') {
                $filters['request'] = $this->data['filters']['request'];
            }
            if (\array_key_exists('status', $this->data['filters']) && (string) $this->data['filters']['status'] !== '0') {
                $const = \strtoupper($this->data['filters']['status']);
                $filters['status'] = \constant("SMACCode::STATUS_{$const}");
            }
            if (\array_key_exists('device', $this->data['filters']) && (string) $this->data['filters']['device'] !== '0') {
                $filters['device'] = \urlencode($this->data['filters']['device']);
            }
            $this->app['filters'] = $this->data['filters'];
        } else {
            $this->app['filters'] = [];
        }
        return $filters;
    }
    public function license_keys_list_json(\Symfony\Component\HttpFoundation\Request $request, \Ministra\Admin\Repository\LicenseKeysRepository $licenseRepository, \Ministra\Admin\Adapter\DataTableAdapter $dataTableAdapter, \Psr\Container\ContainerInterface $container, $local_use = false)
    {
        if (!$this->isAjax && $local_use === false) {
            $this->app->abort(404, $this->setLocalization('Page not found'));
        }
        $dataTableAdapter->setHavingColumns(['key_type'])->process();
        $data = $licenseRepository->getGridData(null, $dataTableAdapter);
        $response = ['data' => [], 'recordsTotal' => $data['total'], 'recordsFiltered' => $data['filter']];
        $response['data'] = \array_map(function ($row) {
            $row['status_flag'] = \strtolower(\str_replace(' ', '_', $row['key_status']));
            $row['added'] = \strtotime($row['added']) * ($this->isAjax ? 1000 : 1);
            $row['action'] = $row['key_status'] == \Ministra\Lib\SMACCode::STATUS_BLOCKED ? 'active' : 'block';
            if (\in_array($row['key_type'], [1, 2])) {
                $row['key_type'] = $this->setLocalization('Standard');
            } else {
                if (\in_array($row['key_type'], [3, 4])) {
                    $row['key_type'] = $this->setLocalization('Advanced');
                } else {
                    $row['key_type'] = $this->setLocalization('Invalid');
                }
            }
            $row['count_clear_attempts'] = $row['count_clear_attempts'] < 0 ? '-' : $row['count_clear_attempts'];
            $row['expire_date'] = $row['expire_date'] < 0 ? $this->setLocalization('Absent') : $row['expire_date'];
            $row['login'] = empty($row['login']) ? $row['user_id'] : $row['login'];
            $row['key_status'] = $row['key_status'] === \Ministra\Lib\SMACCode::STATUS_BLOCKED ? 'BlockedLicense' : $row['key_status'];
            $row['last_active'] = (int) $row['last_active'] > 0 ? $row['last_active'] : null;
            switch ($row['key_status']) {
                case \Ministra\Lib\SMACCode::STATUS_BLOCKED:
                    $row['action'] = 'active';
                    break;
                case \Ministra\Lib\SMACCode::STATUS_NOT_ACTIVATED:
                    $row['action'] = 'block';
                    break;
                case \Ministra\Lib\SMACCode::STATUS_RESERVED:
                    $row['action'] = 'reserved';
                    break;
                default:
                    $row['action'] = 'ignore';
            }
            $row['RowOrder'] = 'dTRow_' . $row['key_id'];
            return $row;
        }, $data['data']);
        $response['data'] = $this->setLocalization($response['data'], 'key_status');
        $error = '';
        if ($this->isAjax && !$local_use) {
            $response = $this->generateAjaxResponse($response);
            return new \Symfony\Component\HttpFoundation\JsonResponse($response, empty($error) ? 200 : 500);
        }
        return $response;
    }
    public function upload_key_file()
    {
        if (!$this->isAjax || $this->method != 'POST') {
            $this->app->abort(404, $this->setLocalization('Page not found'));
        }
        $data = [];
        $data['action'] = 'updateTableData';
        $data['data'] = [];
        $error = $this->setLocalization('Upload failed');
        $storage = new \Upload\Storage\FileSystem('/tmp', true);
        $file = new \Upload\File('files', $storage);
        try {
            $file->upload();
            $result = \Ministra\Lib\SMACCode::importFile($file->getNameWithExtension(), \file_get_contents($file->getPath() . '/' . $file->getNameWithExtension()));
            @\unlink($file->getPath() . '/' . $file->getNameWithExtension());
            if ($result !== false) {
                $data['msg'] = $this->setLocalization('License keys is imported ') . \Ministra\Lib\SMACCode::$countImported;
                $error = '';
            }
        } catch (\Ministra\Lib\SMACLicenseInvalidFormatException $e) {
            $data['msg'] = $this->setLocalization('Invalid format for next license keys') . ': ' . $e->getLicensesAsString();
        } catch (\Ministra\Lib\SMACCodeException $e) {
            $data['msg'] = $this->setLocalization($e->getMessage());
        } catch (\Exception $e) {
            $data['msg'] = $error = $e->getMessage();
        }
        $response = $this->generateAjaxResponse($data);
        return new \Symfony\Component\HttpFoundation\Response(\json_encode($response), empty($error) ? 200 : 500, ['Content-Type' => 'application/json; charset=UTF-8']);
    }
    public function toggle_key_status(\Symfony\Component\HttpFoundation\Request $request, \Ministra\Admin\Repository\LicenseKeysRepository $licenseKeysRepository)
    {
        $data = ['id' => [], 'action' => 'updateTableRow', 'data' => [], 'msg_list' => []];
        $ids = $request->get($request->get('group_key'), $request->get('id'));
        if ($idsData = \json_decode($ids)) {
            $ids = $idsData;
        }
        if (empty($ids)) {
            $this->app->abort(404, $this->setLocalization('Page not found'));
        }
        $action = $this->postData['action'] ?: $request->get('action');
        $licenses = $licenseKeysRepository->updateLicensesStatus($action, $ids);
        $retData = ['data' => $licenses, 'id' => [], 'additional' => []];
        foreach ($licenses as $license) {
            $result = false;
            if (isset($license['is_updated']) && $license['is_updated']) {
                $result = true;
                $retData['id'][$license['id']] = 1;
            } else {
                $retData['id'][$license['id']] = -1;
                $retData['additional']['action'] = 'JSErrorModalBox';
                if (empty($retData['additional']['msg'])) {
                    $retData['additional']['msg'] = $this->setLocalization('Not changed') . ' id:' . $license['id'];
                } else {
                    $retData['additional']['msg'] .= ', ' . $license['id'];
                }
            }
            $retData['msg_list'][$license['key_id']] = $this->groupMessageList($license['id'], $result, $this->updateMessageTemplate());
        }
        $result = \count($retData['id']);
        $data['id'] = \array_filter($retData['id']);
        $error = false;
        if (empty($retData['id'])) {
            $hasError = $result !== \count($retData['id']);
            if (!$hasError) {
                $error = $retData['msg'] = $error = $this->setLocalization('Nothing to do');
            } else {
                $error = $retData['msg'] = $this->setLocalization('Some errors found');
            }
        } else {
            $retData['data'] = $this->setLocalization($licenses['data'], 'status');
            $changed = \array_filter($data['id'], function ($val) {
                return $val !== -1;
            });
            $retData['id'] = \array_keys($retData['id']);
            if (!empty($changed)) {
                $msg_str = 'id: ' . \implode(', ', \array_keys($changed));
                $retData['msg'] = $this->setLocalization('Keys {updchid} has been updated', '', $msg_str, ['{updchid}' => $msg_str]);
            }
        }
        $response = $this->generateAjaxResponse($retData, $error);
        return new \Symfony\Component\HttpFoundation\Response(\json_encode($response), empty($error) ? 200 : 500, ['Content-Type' => 'application/json; charset=UTF-8']);
    }
    private function updateMessageTemplate()
    {
        return ['success' => ['status' => true, 'msg' => $this->setLocalization('Key id:{updid} updated')], 'failed' => ['status' => false, 'msg' => $this->setLocalization('Key id:{updid} not updated')], 'error' => ['status' => false, 'msg' => $this->setLocalization('Update key id:{updid} ended with an error')]];
    }
    public function check_license_keys(\Symfony\Component\HttpFoundation\Request $request, \Ministra\Admin\Repository\LicenseKeysRepository $licenseRepository, \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91 $clearKeyService)
    {
        return $this->clear_license_keys($request, $licenseRepository, $clearKeyService, true, 'Updated');
    }
    public function clear_license_keys(\Symfony\Component\HttpFoundation\Request $request, \Ministra\Admin\Repository\LicenseKeysRepository $licenseRepository, \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91 $clearKeyService, $onlyCheck = false, $clearMessage = 'Cleared')
    {
        if (!\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('util_operator_secret', null) || !\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('operator_key', null)) {
            $data = $this->generateAjaxResponse([], $this->setLocalization('Operator identifiers is empty. Set options util_operator_secret and operator_key in config.ini'));
            return new \Symfony\Component\HttpFoundation\JsonResponse($data, 400);
        }
        $licenses = \json_decode($request->get('ids'), true);
        if (!$licenses) {
            $data = $this->generateAjaxResponse([], $this->setLocalization('Empty list'));
            return new \Symfony\Component\HttpFoundation\JsonResponse($data, 400);
        }
        $invalidFormat = [];
        $denied = [];
        $licenses = $licenseRepository->getByPks($licenses);
        $licensesClearList = [];
        foreach ($licenses as $license) {
            if (!\preg_match("/[\\d][\\d]\\w{10}/", $license['code'])) {
                $invalidFormat[] = ['license' => $license['code'], 'id' => $license['id'], 'message' => $this->setLocalization('Error. License key belongs to other service provider.')];
                continue;
            }
            if (!\is_numeric($license['code'][1]) || $license['code'][1] % 2 !== 0) {
                $denied[] = ['license' => $license['code'], 'id' => $license['id'], 'message' => $this->setLocalization('Error. License key belongs to other service provider.')];
                continue;
            }
            $licensesClearList[] = ['license' => $license['code'], 'id' => $license['id']];
        }
        if (\count($licenses) === \count($denied) + \count($invalidFormat)) {
            $data = $this->generateAjaxResponse(['data' => [\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::e76c0962a6f0166431d335a4b63c5a8c => $denied, \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::d36578ef402b82ceda7706ff76eb92367 => $invalidFormat]], $this->setLocalization('Error. License key belongs to other service provider.'));
            return new \Symfony\Component\HttpFoundation\JsonResponse($data, 200);
        }
        $clearKeyService->a336e23700aa805a337301a960291051($licensesClearList);
        if ($onlyCheck) {
            $clearKeyService->d3a830fd0ab68350753df9f2953b3e2a();
        }
        $data = $clearKeyService->clear();
        if (null === $data || !\is_array($data)) {
            $message = 'Something went wrong. Check your internet connection and try again later.';
            switch ($data) {
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::aaac93373b8fc93014caba6d6375d7f4:
                    $message = '';
                    break;
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::F1145d038a62a52df960e1c06a019f2d8:
                    $message = 'Connection server error';
                    break;
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::U1e722cb1eb59736723d8328ef03669c1:
                    $message = 'Connection to database failed';
                    break;
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::O54afdc760547bae4c46b23679be4a6b5:
                    $message = 'Incorrect operator key or secret phrase';
                    break;
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::f780a698527432ff6350ea3d849505fe:
                    $message = 'Empty';
                    break;
                case \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::v857c93cca7ecf35f572ec60ec879def9:
                    $message = 'Server error. Try again later.';
                    break;
            }
            return new \Symfony\Component\HttpFoundation\JsonResponse($this->generateAjaxResponse([], $this->setLocalization($message)), 500);
        }
        $clearKeyService->S59810324c8414226fae834f0e6384404();
        return new \Symfony\Component\HttpFoundation\JsonResponse(['data' => [\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::e76c0962a6f0166431d335a4b63c5a8c => \array_merge($denied, $this->addMessageForGroupLicenses($clearKeyService->R7ea61fbed908072be14ae9d7f8fb66f7(), 'Error. License key belongs to other service provider.')), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::d36578ef402b82ceda7706ff76eb92367 => $invalidFormat, \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::s0891dd2424606fa50b7544bb50945957 => $this->addMessageForGroupLicenses($clearKeyService->fa8b66a307b241c5dd688221bdd4e021(), $clearMessage), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::n635354a1ffc909861aa5b02ae8550b9f => $this->addMessageForGroupLicenses($clearKeyService->c93c6134f68b1671a6d4d0fbc40fdb6a(), $onlyCheck ? $clearMessage : "Skipped. License key don't have assigned user."), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::p6f834b69a24cdfa2380da41ee557eed6 => $this->addMessageForGroupLicenses($clearKeyService->g3c3b058fe6c1ea1bf88d649c57616327(), 'Error. Limit of clearings is exceeded.'), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::f22f623e296807ae1b4c2a8d24350c69 => $this->addMessageForGroupLicenses($clearKeyService->l1947ac6ae51e25ea9b6e32edc3a0d1d3(), 'Error. License key is expired.'), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::F5601472a65e95ca165929641a32c46ac => $this->addMessageForGroupLicenses($clearKeyService->g8e16a351efe76c88a4990e2dd35e3f0c(), 'Error. License key is blocked.')]], 200);
    }
    private function addMessageForGroupLicenses($list, $message)
    {
        $newList = [];
        foreach ($list as $item) {
            $newList[] = ['message' => $this->setLocalization($message), 'id' => $item['id'], 'license' => $item['license']];
        }
        return $newList;
    }
    private function getCodesFields()
    {
        return ['id' => 'S_C.`id` as `id`', 'code' => 'S_C.`code` as `code`', 'key_type' => 'IF(SUBSTRING(S_C.`code`, 2, 1) IN (1, 2), 1, 2) as `key_type`', 'request' => 'S_C.`request` as `request`', 'added' => 'S_C.`added` as `added`', 'status' => 'S_C.`status` as `status`', 'user_id' => 'S_C.`user_id` as `user_id`', 'device' => 'S_C.`device` as `device`'];
    }
}
