<?php

namespace Ministra\Admin\Command;

use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\m5b8acfc1a27e6359f969c526dc9a7438;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
class UpdateClearUtilCommand extends \Symfony\Component\Console\Command\Command
{
    use \Ministra\Admin\Command\ContainerTrait;
    public function configure()
    {
        $this->setName('mtv:clear-util:update')->setDescription('Update clear util');
    }
    public function execute(\Symfony\Component\Console\Input\InputInterface $input, \Symfony\Component\Console\Output\OutputInterface $output)
    {
        (new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\m5b8acfc1a27e6359f969c526dc9a7438($this->container->get('util.path')))->a4edcf57f9f82098b9566144df69f74c();
    }
}
