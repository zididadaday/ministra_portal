<?php

namespace Ministra\Admin;

use Doctrine\DBAL\DriverManager;
use Ministra\Admin\Adapter\DataTableAdapter;
use Ministra\Admin\Container\SilexPsrContainer;
use Ministra\Admin\Lib\Middleware\Pipelines;
use Ministra\Admin\Repository\LicenseKeysRepository;
use Ministra\Admin\Repository\ServicesPackageRepository;
use Ministra\Admin\Repository\TariffPlanRepository;
use Ministra\Admin\Service\ServicesPackageGrid;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\B49ed084680d7e8666a5b6ad8e110f47d\a6b97e05c01f1c149106a4987bef543c;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\s44b409148252dfd185807b62e507739b as CoreLicenseKeysRepository;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\h5f797e998899d077b7acdd69b6800072;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\m5b8acfc1a27e6359f969c526dc9a7438;
use Pimple\Container;
use Pimple\ServiceProviderInterface;
use Psr\Container\ContainerInterface;
use Silex\Application;
class AppServiceProvider implements \Pimple\ServiceProviderInterface
{
    public function register(\Pimple\Container $container)
    {
        $container->offsetSet(\Psr\Container\ContainerInterface::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Container\SilexPsrContainer($app);
        });
        $container->offsetSet('pipelines', function (\Silex\Application $app) {
            return new \Ministra\Admin\Lib\Middleware\Pipelines();
        });
        $this->registerRepository($container);
        $container->offsetSet(\Ministra\Admin\Adapter\DataTableAdapter::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Adapter\DataTableAdapter($app['request_stack']->getCurrentRequest(), $app['db']);
        });
        $this->registerUtilConnection($container);
        $this->registerUtilService($container);
    }
    protected function registerRepository(\Pimple\Container $container)
    {
        $container->offsetSet(\Ministra\Admin\Repository\LicenseKeysRepository::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Repository\LicenseKeysRepository($app['db']);
        });
        $container->offsetSet(\Ministra\Admin\Repository\TariffPlanRepository::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Repository\TariffPlanRepository($app['db']);
        });
        $container->offsetSet(\Ministra\Admin\Repository\ServicesPackageRepository::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Repository\ServicesPackageRepository($app['db']);
        });
        $container->offsetSet(\Ministra\Admin\Service\ServicesPackageGrid::class, function (\Silex\Application $app) {
            return new \Ministra\Admin\Service\ServicesPackageGrid($app[\Ministra\Admin\Adapter\DataTableAdapter::class], $app[\Ministra\Admin\Repository\ServicesPackageRepository::class], $app[\Ministra\Admin\Repository\TariffPlanRepository::class]);
        });
    }
    protected function registerUtilConnection(\Pimple\Container $container)
    {
        $file = \realpath(__DIR__ . '/../../') . '/deploy/clear_key_util/db_util.sqlite';
        if (!\file_exists($file)) {
            \file_put_contents($file, '');
        }
        if (!\is_writable($file)) {
            throw new \RuntimeException("Clear key util database file does not writable: {$file}");
        }
        $dirs = [\dirname($file) . '/logs', \dirname($file) . '/reports'];
        foreach ($dirs as $dir) {
            if (!\is_writable($file)) {
                throw new \RuntimeException("Directory does not writable: {$dir}");
            }
        }
        if (!\extension_loaded('pdo_sqlite')) {
            throw new \Exception('SQLite extension missing');
        }
        $container->offsetSet('util.connection', \Doctrine\DBAL\DriverManager::getConnection(['driver' => 'pdo_sqlite', 'path' => $file]));
    }
    protected function registerUtilService(\Pimple\Container $container)
    {
        $container->offsetSet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::class, function (\Silex\Application $app) {
            return new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d($app['util.connection']);
        });
        $container->offsetSet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\h5f797e998899d077b7acdd69b6800072::class, function (\Silex\Application $app) {
            return new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\h5f797e998899d077b7acdd69b6800072($app['util.connection']);
        });
        $container->offsetSet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\B49ed084680d7e8666a5b6ad8e110f47d\a6b97e05c01f1c149106a4987bef543c::class, function (\Silex\Application $app) {
            return new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\s44b409148252dfd185807b62e507739b($app['db']);
        });
        $container->offsetSet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91::class, function (\Silex\Application $app) {
            return new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\A54c0a6a3611ca5186e076a4fafde9d91($app->offsetGet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\h5f797e998899d077b7acdd69b6800072::class), $app->offsetGet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\o98a3962afb1661281e19195aaace6aa5\dd91280fc280e19b1661e2df535ea02d::class), $app->offsetGet(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\B49ed084680d7e8666a5b6ad8e110f47d\a6b97e05c01f1c149106a4987bef543c::class), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\D831545b22dfd452c5eb8dbd4cbf8570c\m5b8acfc1a27e6359f969c526dc9a7438::b5c02567bdae54ab3d6e5faa8ad5a6090, $app->offsetGet('util.path'));
        });
    }
}
