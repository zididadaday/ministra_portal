<?php

namespace Ministra\Admin\Lib;

use Ministra\Lib\Itv as LibItv;
class Itv extends \Ministra\Lib\Itv
{
    public static function getServices()
    {
        return \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\S1c3684987a9097329465e9ed8e1f5089::getInstance()->select('id, CONCAT_WS(". ", cast(number as char), name) as name, number')->from('itv')->orderby('number')->get()->all();
    }
}
