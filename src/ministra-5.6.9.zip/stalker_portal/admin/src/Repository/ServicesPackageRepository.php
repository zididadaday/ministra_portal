<?php

namespace Ministra\Admin\Repository;

use Doctrine\DBAL\Connection;
class ServicesPackageRepository
{
    const SERVICES_PACKAGE_TABLE = 'services_package';
    private $connection;
    public function __construct(\Doctrine\DBAL\Connection $connection)
    {
        $this->connection = $connection;
    }
    public function getGridQuery()
    {
        $query = $this->connection->createQueryBuilder()->select(['sp.id', 'sp.external_id', 'sp.name', 'sp.type', 'sp.all_services'])->from(self::SERVICES_PACKAGE_TABLE, 'sp');
        return $query;
    }
}
