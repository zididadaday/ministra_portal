<?php

declare (strict_types=1);
namespace Ministra\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Doctrine\DBAL\Types\Type;
final class Version20211111133720 extends \Doctrine\DBAL\Migrations\AbstractMigration
{
    public function up(\Doctrine\DBAL\Schema\Schema $schema)
    {
        $table = $schema->getTable('updates');
        $table->addColumn('extended', \Doctrine\DBAL\Types\Type::TEXT)->setNotnull(false);
    }
    public function down(\Doctrine\DBAL\Schema\Schema $schema)
    {
        $table = $schema->getTable('updates');
        $table->dropColumn('extended');
    }
    public function getDescription()
    {
        return 'Add history extended';
    }
}
