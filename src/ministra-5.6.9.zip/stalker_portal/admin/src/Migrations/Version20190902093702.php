<?php

namespace Ministra\Migrations;

use Doctrine\DBAL\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\b409830d9f47a4f0a239140a6c2d97ff\fd1b88d17f74608ea3a269430e5ea2ef\s7a2a041201277446cb313d0fbd29ed82;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\b409830d9f47a4f0a239140a6c2d97ff\bd97d698cca44c6baf7b47a077760b8c;
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\J8d411532742ce8f6fc04f6535a9f7c5a\u2dd4ed49a94974905c5424ca14bb3b65;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\ConsoleOutput;
use Symfony\Component\Console\Style\SymfonyStyle;
class Version20190902093702 extends \Doctrine\DBAL\Migrations\AbstractMigration
{
    public function up(\Doctrine\DBAL\Schema\Schema $schema)
    {
        $style = new \Symfony\Component\Console\Style\SymfonyStyle(new \Symfony\Component\Console\Input\ArrayInput([]), new \Symfony\Component\Console\Output\ConsoleOutput());
        $style->createProgressBar();
        $style->success('Start write user device info to statistics table');
        $count = \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\b409830d9f47a4f0a239140a6c2d97ff\bd97d698cca44c6baf7b47a077760b8c::a35e55df074decddb4fe35f54656bf45()->v6141e72b04be8630bb455035f2b597de(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\b409830d9f47a4f0a239140a6c2d97ff\fd1b88d17f74608ea3a269430e5ea2ef\s7a2a041201277446cb313d0fbd29ed82::class)->createQueryBuilder()->select('count(id)')->from('users')->execute()->fetchColumn();
        $style->progressStart($count);
        \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\b409830d9f47a4f0a239140a6c2d97ff\bd97d698cca44c6baf7b47a077760b8c::a35e55df074decddb4fe35f54656bf45()->v6141e72b04be8630bb455035f2b597de(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\J8d411532742ce8f6fc04f6535a9f7c5a\u2dd4ed49a94974905c5424ca14bb3b65::class)->run($style);
        $style->success('End write user device info to statistics table');
    }
    public function down(\Doctrine\DBAL\Schema\Schema $schema)
    {
        if ($schema->hasTable('users_devices_statistic')) {
            $query = $this->connection->getDatabasePlatform()->getTruncateTableSQL('users_devices_statistic');
            $this->addSql($query);
        }
    }
    public function getDescription()
    {
        return 'Migrate data to devices statistics table';
    }
}
