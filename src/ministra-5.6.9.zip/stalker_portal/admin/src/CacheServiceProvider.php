<?php

namespace Ministra\Admin;

use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\A84c4afa74bf45fd448d5db6e666acb99;
use Moust\Silex\Provider\CacheServiceProvider as MCacheServiceProvider;
use Pimple\Container;
class CacheServiceProvider extends \Moust\Silex\Provider\CacheServiceProvider
{
    public function register(\Pimple\Container $app)
    {
        $options = $app->offsetExists('memcache.options') ? $app['memcache.options'] : ['memcache.options' => ['host' => '127.0.0.1', 'default_timeout' => 1800]];
        if (null !== ($instance = $this->checkMemcacheConnect($options['memcache.options']['host']))) {
            $app['caches.options'] = ['memcache' => ['driver' => \get_class($instance) === 'Memcache' ? 'memcache' : 'memcached', 'memcache' => function () use($instance) {
                return $instance;
            }]];
        } else {
            $app['caches.options'] = ['filesystem' => ['driver' => 'file', 'cache_dir' => __DIR__ . '/../resources/cache/admin']];
        }
        return parent::register($app);
    }
    private function checkMemcacheConnect($hosts)
    {
        if (!\class_exists('Memcache') && !\class_exists('Memcached')) {
            return null;
        }
        $memcache = \class_exists('Memcached') ? new \Memcached() : new \Memcache();
        if (!\is_array($hosts)) {
            $hosts = [$hosts];
        }
        $countDisabled = 0;
        foreach ($hosts as $host) {
            if ($memcache->addServer($host, 11211) && $memcache->getStats() && $memcache->set('test', '123')) {
                $memcache->delete('test');
            } else {
                ++$countDisabled;
                \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\A84c4afa74bf45fd448d5db6e666acb99::V30d60331902b7b638b0dfd9f3e6975a4('Could not connect to memcached. Host: ' . $host);
            }
        }
        return $countDisabled === \count($hosts) ? null : $memcache;
    }
}
