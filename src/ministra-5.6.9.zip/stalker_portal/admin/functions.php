<?php

use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\A84c4afa74bf45fd448d5db6e666acb99;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
if (!\function_exists('admin_controller_resolver')) {
    function admin_controller_resolver()
    {
        $app = $namespace = $controller = $action = \null;
        $variables = ['app', 'namespace', 'controller', 'action'];
        $func_args = \func_get_args();
        foreach ($func_args as $key => $val) {
            ${$variables[$key]} = $val;
        }
        $action = !empty($action) ? \str_replace('-', '_', $action) : 'index';
        $controllerName = "\\{$namespace}\\" . \implode('', \array_map('ucfirst', \explode('-', \strtolower($controller)))) . 'Controller';
        if (\class_exists($controllerName) && \method_exists($controllerName, $action)) {
            $controller = new $controllerName($app);
            if ($controller instanceof $controllerName) {
                if (\is_callable([$controller, $action])) {
                    $reflection = new \ReflectionClass(\get_class($controller));
                    $method = $reflection->getMethod($action);
                    $parameters = $method->getParameters();
                    $request = $app['request_stack']->getCurrentRequest();
                    $resolved = [];
                    foreach ($parameters as $parameter) {
                        $class = $parameter->getClass();
                        if ($class) {
                            if ($class->getName() === \Silex\Application::class) {
                                $resolved[] = $app;
                            } else {
                                if ($class->getName() === \Symfony\Component\HttpFoundation\Request::class || \class_implements(\Symfony\Component\HttpFoundation\Request::class, $class->getName())) {
                                    $resolved[] = $request;
                                } else {
                                    $resolved[] = $app[$class->getName()];
                                }
                            }
                            continue;
                        }
                        $value = $request->get($parameter->getName(), \null);
                        if (\null === $value) {
                            if (!$parameter->isDefaultValueAvailable()) {
                                throw new \InvalidArgumentException("Argument `{$parameter->getName()}` for {$controllerName}::{$action} does not defined");
                            }
                            $value = $parameter->getDefaultValue();
                        }
                        $resolved[] = $value;
                    }
                    return \call_user_func_array([$controller, $action], $resolved);
                }
            }
        }
        return $app->abort(404, \sprintf('No route found for: %s:%s', $controllerName, $action));
    }
}
if (!\function_exists('optionsConcat')) {
    function optionsConcat(&$var, $fields = [], $options = [])
    {
        foreach ($fields as $field) {
            if (!empty($options[$field])) {
                $var .= $options[$field];
            }
        }
    }
}
if (!\function_exists('adminLogError')) {
    function adminLogError(\Silex\Application $app, $e)
    {
        $message = $e->getMessage() . \PHP_EOL . $e->getTraceAsString();
        if ($app->offsetExists('monolog')) {
            $app->offsetGet('monolog')->error($message);
        } else {
            \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\A84c4afa74bf45fd448d5db6e666acb99::V30d60331902b7b638b0dfd9f3e6975a4($message);
        }
    }
}
