<?php

require_once '../server/common.php';
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426;
if (!\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('enable_soap_api', \false)) {
    \header($_SERVER['SERVER_PROTOCOL'] . ' 403 Forbidden');
    echo 'SOAP API is not enabled';
    exit;
}
require_once __DIR__ . '/../vendor/rock/phpwsdl/src/Rock/PhpWsdl/class.phpwsdl.php';
use Ministra\Lib\SOAPApi\v1\SoapApiServer;
$api_server = new \Ministra\Lib\SOAPApi\v1\SoapApiServer();
if (isset($_GET['wsdl'])) {
    $api_server->outputWsdl();
} elseif (isset($_GET['docs'])) {
    $api_server->outputDocs();
} elseif (isset($_GET['phpsoapclient'])) {
    $api_server->outputPhpClient();
} else {
    $api_server->handleRequest();
}
