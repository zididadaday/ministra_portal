<?php

require_once '../../server/common.php';
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426;
use Ministra\Lib\RESTAPI\v1\RESTManager;
if (!\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('enable_api', \false) && \strpos($_SERVER['QUERY_STRING'], 'tv_archive') != 2 && \strpos($_SERVER['QUERY_STRING'], 'stream_recorder') != 2 && \strpos($_SERVER['QUERY_STRING'], 'monitoring_links') != 2 && \strpos($_SERVER['QUERY_STRING'], 'tv_tmp_link') != 2) {
    \header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
    echo 'API not enabled';
    exit;
}
\Ministra\Lib\RESTAPI\v1\RESTManager::setAuthParams(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('api_auth_login', ''), \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('api_auth_password', ''));
\Ministra\Lib\RESTAPI\v1\RESTManager::enableLogger(\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\P721a11cf1442c175bf89e092a7b0d426::getSafe('enable_api_log', \false));
\Ministra\Lib\RESTAPI\v1\RESTManager::handleRequest();
