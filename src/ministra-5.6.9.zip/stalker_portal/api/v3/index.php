<?php

require_once '../../server/common.php';
use Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\cd73e249da905f4e9d282b4a6e168d5a;
use Ministra\Lib\f4ae6b86539a3025a5acb300a1328d88\d05b0deb8ea28f90fe9d34a59dec5db2\m5ca065dd8e9ac5d52843db1740e5feb2;
$server = new \Ministra\Lib\f4ae6b86539a3025a5acb300a1328d88\d05b0deb8ea28f90fe9d34a59dec5db2\m5ca065dd8e9ac5d52843db1740e5feb2(new \Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\cd73e249da905f4e9d282b4a6e168d5a());
$server->handleRequest();
