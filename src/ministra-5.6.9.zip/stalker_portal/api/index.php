<?php

require_once '../server/common.php';
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\c747a8d542898c23548f39ceb4c037ad\O9ff0b521e39ffae733a74ac96e1ba62c;
(new \Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\c747a8d542898c23548f39ceb4c037ad\O9ff0b521e39ffae733a74ac96e1ba62c())->run();
