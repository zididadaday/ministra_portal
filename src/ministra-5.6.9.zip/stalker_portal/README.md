## Ministra TV Platform

[Project description](https://www.infomir.eu/eng/solutions/ministra-tv-platform)

[Wiki](https://wiki.infomir.eu)

[Installation guide](https://wiki.infomir.eu/eng/stalker/stalker-installation-guide)

[User group](http://ideas.ministra.com)
