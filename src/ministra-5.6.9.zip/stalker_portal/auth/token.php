<?php

require_once __DIR__ . '/../server/common.php';
use Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\afd7d9230bec2066a176c34c97456647;
use Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\cd73e249da905f4e9d282b4a6e168d5a;
use Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\c00e704ca703c98d66eab424be8e21be;
\Ministra\Lib\o90ec47ed214103f50544c5cffbda44c4\d74ec08c4632eb7ce139d98bf3abc193\afd7d9230bec2066a176c34c97456647::Q83b529ccdb254a5016e9a78562f56c34('Api v3 begin');
$oauth_server = new \Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\c00e704ca703c98d66eab424be8e21be(new \Ministra\Lib\C01e1fce1feb2ce5b116d513d6b8501c3\cd73e249da905f4e9d282b4a6e168d5a());
$oauth_server->s6c5f8284f14e6b73838f9e8beb6f6110();
